# DMR Construction PVT. LTD.
## Store Management System — v1.0.0

A complete, production-ready multi-user store management system built in PHP with MySQL.

---

## 📁 File Structure

```
dmr-store/
│
├── index.php                    ← Root redirect
├── dashboard.php                ← Main dashboard
├── inventory.php                ← Inventory management
├── products.php                 ← Product master CRUD
├── indents.php                  ← Indent requests (raise, approve, reject)
├── issues.php                   ← Issue requests (raise, approve, reject, slip)
├── stock.php                    ← Stock ledger, stock-in, adjustments
├── users.php                    ← User management
├── reports.php                  ← Reports and analytics
├── audit.php                    ← Immutable audit log
│
├── auth/
│   ├── login.php                ← Login page
│   └── logout.php               ← Session destroy
│
├── config/
│   ├── config.php               ← App config, auth helpers, permissions
│   └── db.php                   ← PDO connection
│
├── includes/
│   ├── functions.php            ← Core helper functions
│   ├── header.php               ← Sidebar + topbar layout
│   └── footer.php               ← Closing tags + JS
│
├── assets/
│   ├── css/style.css            ← Complete stylesheet
│   └── js/main.js               ← Frontend JavaScript
│
├── actions/
│   └── mark_notif_read.php      ← Mark notifications read
│
├── reports_export/
│   ├── export.php               ← Universal CSV/Print exporter
│   └── issue_slip.php           ← Printable issue slip
│
└── install/
    ├── index.php                ← Web-based installer
    └── database.sql             ← Complete schema + seed data
```

---

## 🚀 Quick Setup

### Option A — Web Installer (Recommended)
1. Upload the `dmr-store/` folder to your server/`htdocs`
2. Visit: `http://yoursite.com/dmr-store/install/`
3. Fill in database credentials and click **Install**
4. **Delete the `install/` folder** after setup

### Option B — Manual Setup
1. Create database: `CREATE DATABASE dmr_store CHARACTER SET utf8mb4;`
2. Import schema: `mysql -u root -p dmr_store < install/database.sql`
3. Edit `config/db.php` with your credentials
4. Visit: `http://yoursite.com/dmr-store/`

### XAMPP / WAMP / Local
1. Copy `dmr-store/` to `htdocs/` (XAMPP) or `www/` (WAMP)
2. Start Apache + MySQL
3. Visit `http://localhost/dmr-store/install/`

---

## 🔐 Demo Login Credentials

| Role          | Username                        | Password    |
|---------------|---------------------------------|-------------|
| Store Admin   | admin@dmrconstruction.in        | Admin@1234  |
| Store Keeper  | keeper@dmrconstruction.in       | Admin@1234  |
| Employee      | deepak@dmrconstruction.in       | Admin@1234  |
| Management    | mgmt@dmrconstruction.in         | Admin@1234  |

> ⚠️ **Change all passwords immediately after first login in production!**

---

## 👥 Role Permissions

| Feature                  | Admin | Keeper | Employee | Management |
|--------------------------|-------|--------|----------|------------|
| Dashboard                | ✅    | ✅     | ✅       | ✅         |
| View Inventory           | ✅    | ✅     | ✅       | ✅         |
| Add/Edit Products        | ✅    | ❌     | ❌       | ❌         |
| Stock In                 | ✅    | ✅     | ❌       | ❌         |
| Stock Adjustment         | ✅    | ❌     | ❌       | ❌         |
| Raise Issue Request      | ✅    | ✅     | ✅       | ❌         |
| Approve/Reject Issues    | ✅    | ✅     | ❌       | ❌         |
| Raise Indent             | ✅    | ✅     | ✅       | ❌         |
| Approve/Reject Indents   | ✅    | ✅     | ❌       | ❌         |
| Stock Ledger             | ✅    | ✅     | ❌       | ✅         |
| User Management          | ✅    | ❌     | ❌       | ❌         |
| Reports & Export         | ✅    | ✅     | ❌       | ✅         |
| Audit Log                | ✅    | ❌     | ❌       | ✅         |

---

## ⚙️ Server Requirements

- **PHP:** 7.4 or higher (8.x recommended)
- **MySQL:** 5.7+ or MariaDB 10.3+
- **Extensions:** `pdo_mysql`, `session`, `mbstring`
- **Web Server:** Apache / Nginx / XAMPP / WAMP

### Apache `.htaccess` (Optional — for clean URLs)
```apache
RewriteEngine On
RewriteRule ^$ index.php [QSA,L]
```

---

## 🗄️ Key Database Tables

| Table                | Purpose                              |
|----------------------|--------------------------------------|
| `users`              | All system users with roles          |
| `categories`         | Product categories                   |
| `products`           | Product master with stock levels     |
| `stock_transactions` | Immutable ledger of every stock move |
| `indents`            | Indent/new-item requests             |
| `issue_requests`     | Material issue requests              |
| `notifications`      | In-app notification system           |
| `audit_log`          | Immutable complete activity trail    |
| `counters`           | Auto-number sequences                |

---

## 🔒 Security Features

- **BCrypt password hashing** (cost 12)
- **CSRF token** on all POST forms
- **Session regeneration** on login
- **Role-based access control** on every page
- **Prepared statements** throughout (SQL injection safe)
- **Output escaping** via `e()` helper (XSS safe)
- **Immutable audit log** (no delete/update allowed)
- **Session timeout** (1 hour idle)
- **HTTPOnly + SameSite cookies**

---

## 📑 Export Formats

All reports can be exported as:
- **CSV** — Opens in Excel/Google Sheets
- **HTML Print** — Browser print-to-PDF

Available reports:
1. Daily Issue Report
2. Stock Summary
3. Low Stock Alert
4. Employee Issue History
5. Category-wise Stock
6. Stock Movement Ledger
7. Audit Log Export
8. Issue Slip (per issue)

---

## 🔧 Configuration

Edit `config/config.php` to change:
```php
define('TIMEZONE',        'Asia/Kolkata');    // Your timezone
define('SESSION_LIFETIME', 3600);             // Session timeout (seconds)
define('ROWS_PER_PAGE',    25);               // Pagination
define('APP_NAME',        'DMR Store...');    // App title
```

---

## 📞 Support

DMR Construction PVT. LTD.
Store Management System — Built for internal use.

> Delete `install/` folder and restrict directory listing in production.
